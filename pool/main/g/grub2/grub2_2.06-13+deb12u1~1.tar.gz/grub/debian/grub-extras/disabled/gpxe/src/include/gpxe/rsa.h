#ifndef _GPXE_RSA_H
#define _GPXE_RSA_H

FILE_LICENCE ( GPL2_OR_LATER );

struct pubkey_algorithm;

extern struct pubkey_algorithm rsa_algorithm;

#include "crypto/axtls/crypto.h"

#endif /* _GPXE_RSA_H */
