#ifndef _GPXE_AES_H
#define _GPXE_AES_H

FILE_LICENCE ( GPL2_OR_LATER );

struct cipher_algorithm;

extern struct cipher_algorithm aes_cbc_algorithm;

#endif /* _GPXE_AES_H */
