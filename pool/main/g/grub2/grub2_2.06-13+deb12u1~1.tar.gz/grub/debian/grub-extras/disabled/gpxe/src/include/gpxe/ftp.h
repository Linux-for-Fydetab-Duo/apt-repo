#ifndef _GPXE_FTP_H
#define _GPXE_FTP_H

/** @file
 *
 * File transfer protocol
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

/** FTP default port */
#define FTP_PORT 21

#endif /* _GPXE_FTP_H */
