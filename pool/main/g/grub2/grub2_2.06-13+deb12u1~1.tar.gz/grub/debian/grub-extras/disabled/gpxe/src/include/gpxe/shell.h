#ifndef _GPXE_SHELL_H
#define _GPXE_SHELL_H

/** @file
 *
 * Minimal command shell
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

extern void shell ( void );

#endif /* _GPXE_SHELL_H */
