#ifndef _GPXE_SHELL_BANNER_H
#define _GPXE_SHELL_BANNER_H

/** @file
 *
 * Shell startup banner
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

extern int shell_banner ( void );

#endif /* _GPXE_SHELL_BANNER_H */
